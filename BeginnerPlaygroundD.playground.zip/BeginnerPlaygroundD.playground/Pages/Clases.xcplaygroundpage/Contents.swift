//: [Previous](@previous)

import Foundation

// Clases

class Programmer {
    let name: String
    let age: Int
    let languages: [Language]
    var friends: [Programmer]?
    
    enum Language{
        case swift
        case kotlin
        case java
        case javaScript
    }
    
    init(name: String, age: Int, languages: [Language]) {
        self.name = name
        self.age = age
        self.languages = languages
    }
    
    func code(){
        print ("Estoy Programando... \(languages)")
    }
}

let diego = Programmer(name: "Diego", age: 34, languages: [.swift, .kotlin])
diego.code()

let sara = Programmer(name: "Sara", age: 28, languages: [.swift, .java])
sara.code()
diego.friends = [sara]
print(diego.friends?.first?.name)
//: [Next](@next)
