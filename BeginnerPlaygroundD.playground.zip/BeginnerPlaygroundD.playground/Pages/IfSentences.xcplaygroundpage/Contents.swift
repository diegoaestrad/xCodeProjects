//: [Previous](@previous)

import Foundation

let myNumber1 = 2

/**
 ==    igual      >= mayor o igual que        <= menor o igual que     > mayor que           < menor que       != diferente o desigual

&& Operador "y"
|| Operador "o"
 */

if (myNumber1 > 5 && myNumber1 < 10) || myNumber1 >= 50{
    print("\(myNumber1) es mayor que 5 y menor a 10 o mayor a 50")
} else if myNumber1 == 1{
    print("\(myNumber1) es igual a 1")
}else {
    print("\(myNumber1) es menor a 5 o mayor o igual a 10 pero menor a 50")
}

//: [Next](@next)
