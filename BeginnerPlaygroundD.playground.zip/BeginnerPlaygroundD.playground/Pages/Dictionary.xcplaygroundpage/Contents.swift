//: [Previous](@previous)

import Foundation

let myOldDictionary = Dictionary<String,Int>()//clasica
var myNewDictionary = [String:Int]()//actual

myNewDictionary = ["Diego":001,"Deisy":002,"Oscar":003,"Marina":004]
print (myNewDictionary)

myNewDictionary["Estrada"] = 005
myNewDictionary["Beltran"] = 006
print (myNewDictionary)
myNewDictionary.updateValue(012,forKey: "Test")
print (myNewDictionary)
print (myNewDictionary["Diego"])
myNewDictionary.updateValue(002,forKey: "Deisy Sanchez")
print (myNewDictionary)
myNewDictionary["Test"] = nil
print (myNewDictionary)
myNewDictionary.removeValue(forKey: "Beltran")
print (myNewDictionary)
//acceso a un dato


//: [Next](@next)
