//: [Previous](@previous)

import Foundation

//opcionales
let myString = "12345"
let myInt = Int(myString)
print(myInt)

if myInt != nil{
    print(myInt! + 10)// cuando se agrega el ! ya no es un opcional
}

//definicion opcional
var myNewString: String?
print (myNewString)
myNewString = "Diego"
print (myNewString)
if myNewString != nil {
    print(myNewString!)
}else{
    print(myNewString)
}

if let myNoNilString = myNewString{
    print(myNoNilString)
}else{
    print(myNewString)
}
//: [Next](@next)
