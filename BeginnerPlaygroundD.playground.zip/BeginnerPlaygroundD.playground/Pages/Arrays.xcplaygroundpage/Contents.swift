//: [Previous](@previous)

import Foundation

let fName = "Diego"
let sName = "Alejandro"
let lName = "Estrada"
let country = "Colombia"
let age = "34"

var myArray = Array<String>()
var myArray2 = [String]()

myArray2.append(fName)
myArray2.append(sName)
myArray2.append(lName)
myArray2.append(country)
myArray2.append(age)
print(myArray2)
myArray2.append(contentsOf:["222","333"])
print(myArray2)
myArray2[2] += " Beltran"
print(myArray2)
myArray2.remove(at: 5)
print(myArray2)
for value in myArray2{
    print(value)
}
//: [Next](@next)
