//: [Previous](@previous)

import Foundation

//funciones
func sayHello(){
    print("Hello Diego")
}

sayHello()

func sayMyName(name: String){
    print("Hola me llamo \(name)")
}
sayMyName(name: "Diego")
sayMyName(name: "Alejandro")

func sayMyNameAndAge(name: String, age: Int){
    print("Hola me llamo \(name) y mi edad es \(age)")
}
sayMyNameAndAge(name: "Diego", age: 34)
sayMyNameAndAge(name: "Alejandro", age: 35)

func helloString () -> (String){
    return "hello"
}
print(helloString())

func sumTwoNumbers(firstNumber: Int, secondNumber: Int) -> (Int){
    let sum = firstNumber + secondNumber
    return sum
}
print(sumTwoNumbers(firstNumber: 5, secondNumber: 10))

func callFunctions(){
    sayHello()
    sayMyNameAndAge(name: "Diego", age: 34)
    print(helloString)
    print(sumTwoNumbers(firstNumber: 7, secondNumber: 13))
}
//: [Next](@next)
