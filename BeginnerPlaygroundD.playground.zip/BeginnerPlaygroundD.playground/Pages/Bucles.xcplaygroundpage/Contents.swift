//: [Previous](@previous)

import Foundation

let myStringArray = ["Hola","Soy","Diego"]
let myNewDictionary = ["Hello":002,"I am":001,"Diego Alejandro":007]

//for
for stringElement in myStringArray{
    print(stringElement)
}

for dictEement in myNewDictionary{
    print(dictEement)
}

for index in 1 ... 5 {
    print(index)
}

for index in 1 ..< 5 {
    print(index)
}
myNewDictionary.forEach{ (key, value) in
    print("\(key):\(value)")
}

// while
var myNumberArray: [Int] = []
for index in 1 ... 20 {
    myNumberArray.append(index)
}
print(myNumberArray)

var index = 0
while index < 10 {
    print(myNumberArray[index])
    index += 1
}

// Repeat While
index = 0
repeat {
    print(myNumberArray[index])
    index += 1
}while index < 10
//: [Next](@next)
