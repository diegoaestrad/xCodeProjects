//: [Previous](@previous)

import Foundation

// variables
/** Bloque de comentario
    Variables
 */

var username = "Diego"
var userAge = 34
var currentYear = 2020

print(username,"born in",currentYear-userAge, "and is",userAge,"years old")

var userLastName = "Estrada"

print(username,userLastName)

let noChangeValue = "no chaged"
print(noChangeValue)
//noChangeValue = "jaja" // A let value can not be changed after a value is assigned
//print(noChangeValue)
//: [Next](@next)
