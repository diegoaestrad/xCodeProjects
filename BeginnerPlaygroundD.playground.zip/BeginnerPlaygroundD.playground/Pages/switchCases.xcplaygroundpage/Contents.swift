//: [Previous](@previous)

import Foundation

let country = "EEUU"

switch country {
    case "España", "Colombia", "Peru", "Ecuador":
        print("Español")
    case "EEUU":
        print("Ingles")
    case "Alemania":
    print("Aleman")
default:
    print("Idioma Distinto")
}

let age = 34
switch age {
case 0,1,2:
        print("baby age")
case 3 ... 10:
        print("kid age")
case 11 ..< 18:
        print("young age")
case 18 ..< 70:
        print("adult age")
case 70 ..< 100:
    print("more than adult age")
default:
    print(" :O ")
}

//: [Next](@next)
