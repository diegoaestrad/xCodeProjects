//: [Previous](@previous)

import Foundation

//String
let myString: String = "Diego String with let"
let myString2 = "Diego String2 with let"
let myString3 = myString+" "+myString2
print(myString3)

//Int
let myInt = 1
let myInt2 = 2
let myInt3 = myInt+myInt2
print(myInt3)


//Double
let myDouble = 1.5
let myDouble2 = 1.7
let myDouble3 = myDouble+myDouble2
print(myDouble3)

//Float
let myFloat1: Float = 1.5
let myFloat2: Float = 1.9
let myFloat3 = myFloat1+myFloat2

print(myFloat3)
//Bool
let myBool1 = true
let myBool2 = false
let myBool3 = myBool1 && myBool2
print(myBool3)
print(myBool1 && myBool2)
print(myBool1 || myBool2)
print(myBool1 == myBool2)
print(myBool1 != myBool2)

//: [Next](@next)
